require('@babel/register');
require('./src');
