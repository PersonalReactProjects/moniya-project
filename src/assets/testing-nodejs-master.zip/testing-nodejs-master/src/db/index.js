import users from './users';
import posts from './posts';

export default { users, posts };
